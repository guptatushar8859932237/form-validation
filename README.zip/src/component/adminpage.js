import React from 'react'

export default function Admin(){

    return(
        <>
        <hellow>hellow</hellow>
        </>
    )
}