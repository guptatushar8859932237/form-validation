import { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';

function BasicExample() {
  const [data, setData] = useState(" ")
  const [error, setError] = useState({})


  const handlechange = (e) => {
    const { name, value } = e.target
    setData({ ...data, [name]: value })
  }

  const handlevalidate = (value) => {
    let error = {}
    if (!value.email) {
      error.email = 'email required'
    } if (!value.password) {
      error.password = "password required"
    } else { console.log('something wrong') 
  }

    setError(error)

  }
  const handleclick = () => {
    handlevalidate(data)

  }

  return (
<>
        <div className='container21'>
          <div className='form12'>
            <h1 className='heading'>sign in</h1>
      
        <Form.Control type="email" name='email' onChange={handlechange} placeholder="Enter email" />
        <p className='valid'>{error.email}</p>
        <Form.Control type="password" name='password' onChange={handlechange} placeholder="Password" />
        <p className='valid'>{error.password}</p>
      <Button variant="primary" onClick={handleclick} type="submit">
        Submit
      </Button>
      <p>Already have account? <a href='/login'> Login</a></p>
      </div>
     <div className='imageform'></div>
      </div>  

      <div className='bod'></div>    
      </>
  );
}
export default BasicExample;