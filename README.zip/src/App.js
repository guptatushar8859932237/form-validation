import React from "react";
import BasicExample from "./component/sign";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Login from "./component/login";
import Admin from "./component/adminpage";

export default function App(){
  return(
  <>
  <BrowserRouter>
  <Routes>
  
    <Route path="/login" element={<Login/>} />
    <Route path="/" element={<BasicExample/>} />
    <Route path="/admin" element={<Admin/>} />

  </Routes>
  </BrowserRouter>
     </>
  )
}